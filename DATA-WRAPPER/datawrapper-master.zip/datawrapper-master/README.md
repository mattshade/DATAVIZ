# Datawrapper

Datawrapper is a tool that enables anyone to create enticing visualizations in seconds, without any programming skills.

It draws inspiration from [ManyEyes](http://www-958.ibm.com/software/data/cognos/manyeyes/) and [GoogleCharts](https://developers.google.com/chart/) but remains entirely open-source and independent from a third-party server.

It was created by [Mirko Lorenz](http://www.mirkolorenz.com/), [Nicolas Kayser-Bril](http://nkb.fr) and [Gregor Aisch](http://driven-by-data.net/) and was funded by [ABZV](http://www.abzv.de/).

* Live service: <http://datawrapper.de/>
* Documentation: <http://docs.datawrapper.de/> ([Install](http://docs.datawrapper.de/en/install/))

## Contact

* IRC: #datawrapper on [freenode.net](https://webchat.freenode.net/)
* Twitter: [@datawrapper](http://twitter.com/datawrapper)
* Blog: [blog.datawrapper.de](http://blog.datawrapper.de)
