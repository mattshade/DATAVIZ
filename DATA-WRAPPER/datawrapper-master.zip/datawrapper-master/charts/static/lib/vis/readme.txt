This is where the static copies of the visualization libraries will be stored.
