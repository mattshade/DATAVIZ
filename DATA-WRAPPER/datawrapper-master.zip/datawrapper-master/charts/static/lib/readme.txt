In this folder Datawrapper will store versioned copies of themes and
visualizations, in order to ensure that previously created charts won't
break after substantial updates.