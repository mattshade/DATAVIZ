This is where static copies of the themes will be stored.
