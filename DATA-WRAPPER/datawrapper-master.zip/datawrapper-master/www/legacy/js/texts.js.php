//This file contains all translations that will be used in JS

var texts = {};

texts.no_data = "<?php echo _("No data was input."); ?>";
texts.chart_deleted = "<?php echo _("Chart deleted."); ?>";