<?php

/**
 * Datawrapper main index
 *
 */



define('DATAWRAPPER_VERSION', '1.7.2');  // must be the same as in package.json

define('ROOT_PATH', '../');

require_once ROOT_PATH . 'lib/utils/check_server.php';

check_server();

require ROOT_PATH . 'lib/bootstrap.php';

$twig = $app->view()->getEnvironment();

require ROOT_PATH . 'lib/utils/twig-init.php';

require_once ROOT_PATH . 'lib/utils/disable_cache.php';
require_once ROOT_PATH . 'lib/utils/add_header_vars.php';
require_once ROOT_PATH . 'lib/utils/add_editor_nav.php';

require_once ROOT_PATH . 'lib/utils/errors.php';
require_once ROOT_PATH . 'lib/utils/check_chart.php';
require_once ROOT_PATH . 'controller/plugin-templates.php';
require_once ROOT_PATH . 'controller/home.php';
require_once ROOT_PATH . 'controller/login.php';
require_once ROOT_PATH . 'controller/account-settings.php';
require_once ROOT_PATH . 'controller/account-activate.php';
require_once ROOT_PATH . 'controller/account-set-password.php';
require_once ROOT_PATH . 'controller/account-reset-password.php';
require_once ROOT_PATH . 'controller/chart-create.php';
require_once ROOT_PATH . 'controller/chart-edit.php';
require_once ROOT_PATH . 'controller/chart-upload.php';
require_once ROOT_PATH . 'controller/chart-describe.php';
require_once ROOT_PATH . 'controller/chart-visualize.php';
require_once ROOT_PATH . 'controller/chart-data.php';
require_once ROOT_PATH . 'controller/chart-preview.php';
require_once ROOT_PATH . 'controller/chart-embed.php';
require_once ROOT_PATH . 'controller/chart-publish.php';
require_once ROOT_PATH . 'controller/chart-static.php';
require_once ROOT_PATH . 'controller/mycharts.php';
require_once ROOT_PATH . 'controller/xhr.php';
require_once ROOT_PATH . 'controller/docs.php';
require_once ROOT_PATH . 'controller/admin.php';


$app->notFound(function() {
    error_not_found();
});

if ($dw_config['debug']) {
    $app->get('/phpinfo', function() use ($app) {
        phpinfo();
    });
}

/*
 * before processing any other route we check if the
 * user is not logged in and if prevent_guest_access is activated.
 * if both is true we redirect to /login
 */
$app->hook('slim.before.router', function () use ($app, $dw_config) {
    $user = DatawrapperSession::getUser();
    if (!$user->isLoggedIn() && !empty($dw_config['prevent_guest_access'])) {
        $req = $app->request();
        if (UserQuery::create()->filterByRole(array('admin', 'sysadmin'))->count() > 0) {
            if ($req->getResourceUri() != '/login' &&
                strncmp($req->getResourceUri(), '/account/invite/', 16) && // and doesn't start with '/account/invite/'
                strncmp($req->getResourceUri(), '/account/reset-password/', 24)) { // and doesn't start with '/account/reset-password/'
                $app->redirect('/login');
            }
        } else {
            if ($req->getResourceUri() != '/setup') {
                $app->redirect('/setup');
            }
        }
    }
});


/**
 * Step 4: Run the Slim application
 *
 * This method should be called last. This is responsible for executing
 * the Slim application using the settings and routes defined above.
 */

$app->run();

