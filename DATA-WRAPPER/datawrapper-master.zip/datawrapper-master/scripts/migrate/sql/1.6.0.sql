ALTER TABLE `user` ADD COLUMN `oauth_signin` VARCHAR(512);
