ALTER TABLE `chart` CHANGE `author_id` `author_id` INTEGER;
