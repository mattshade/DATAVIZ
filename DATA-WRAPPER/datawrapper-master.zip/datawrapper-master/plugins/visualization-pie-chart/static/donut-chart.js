
(function(){

    dw.visualization.register('donut-chart', 'pie-chart', {

        isDonut: function() {
            return true;
        }

    });

}).call(this);