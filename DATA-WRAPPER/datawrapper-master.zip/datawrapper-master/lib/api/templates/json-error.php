<?php

print json_encode(array('status'=>'error', 'error'=>$this->data['msg']));