<?php

/*
 * template for the Datawrapper activation email
 */

$password_reset_mail = __("
Hello %name%,

Someone, probably you, filed a request to reset your password.

If that's true, please click the following link to reset your password.

%password_reset_link%

If you ignore this email, your password stays the same as before.

Best,
Datawrapper

");